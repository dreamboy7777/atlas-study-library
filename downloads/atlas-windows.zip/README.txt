Atlas 1.0.0 - portable Windows build
====================================

Atlas is a local-first study library. Your accounts, PDFs, chat,
memes, and settings stay on this computer. There is no Atlas server.

Quick start
-----------
1. Unzip this folder anywhere you like.
2. Double-click "Start Atlas.bat".
3. Use the same browser on the same computer to keep your library.

Recommended browser: Chrome or Edge. Firefox works too, but PDF
preview and file handling are most consistent in Chromium browsers.

Optional desktop shortcut
-------------------------
Right-click "Create Desktop Shortcut.ps1" and choose
"Run with PowerShell". It creates an Atlas shortcut with the app icon.

Where is my data?
-----------------
Atlas stores data in the browser profile for the folder you opened.
If you move the folder to a different path, the browser may treat it as
a new site and show an empty library. Keep the folder in one place, or
export a JSON backup from the Admin console before moving it.

Admin access
------------
The default staff passcode is in README.md and SETUP.md in the main
repository. Change it from Admin console -> Site settings after your
first login.

Mobile apps
-----------
Android APK and iPhone IPA downloads live in the main repository's
download page (download.html).
