$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$shell = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath("Desktop")
$linkPath = Join-Path $desktop "Atlas.lnk"
$link = $shell.CreateShortcut($linkPath)
$link.TargetPath = Join-Path $root "Start Atlas.bat"
$link.WorkingDirectory = $root
$link.IconLocation = (Join-Path $root "assets\atlas.ico") + ",0"
$link.Description = "Atlas study library"
$link.Save()
Write-Host "Created Atlas shortcut on the desktop."
