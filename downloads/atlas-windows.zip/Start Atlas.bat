@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0atlas.html" (
  echo Atlas could not find atlas.html next to this launcher.
  pause
  exit /b 1
)
start "" "%~dp0atlas.html"
